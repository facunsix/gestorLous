// This client has been deprecated - Supabase client is now created inline where needed
// Keeping this file to avoid build errors, but it's no longer used

export const supabase = null;