// This component has been deprecated and replaced by TaskManager.tsx
// Keeping this file to avoid build errors, but it's no longer used

export default function TaskCard() {
  return null;
}