// This component has been deprecated and replaced by Dashboard.tsx
// Keeping this file to avoid build errors, but it's no longer used

export default function TaskTimeline() {
  return null;
}