
  # Sistema de Gestión de Tareas con Supabase

  This is a code bundle for Sistema de Gestión de Tareas con Supabase. The original project is available at https://www.figma.com/design/Xqhjb4OpQ4vGxFxe23Q1jN/Sistema-de-Gesti%C3%B3n-de-Tareas-con-Supabase.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  